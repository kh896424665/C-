package com.example.ggxiaozhi.store.the_basket.base.mvpbase;

/**
 * 工程名 ： BaiLan
 * 包名   ： com.example.ggxiaozhi.store.the_basket.base.mvpbase
 * 作者名 ： 志先生_
 * 日期   ： 2017/8/26
 * 时间   ： 13:36
 * 功能   ：所有接口View的基类
 */

public interface BaseView {

    void showToast(String msg);
}
